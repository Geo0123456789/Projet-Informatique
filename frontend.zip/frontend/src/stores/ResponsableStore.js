import axios from '@/lib/axios'
import { defineStore } from 'pinia'

export const useResponsableStore = defineStore('responsable', {
  state: () => ({
    modules: [],
    stats: {},
  }),
  actions: {
    async fetchModules() {
      const res = await axios.get('/modules')
      this.modules = res.data
    },
    async fetchStats(moduleId) {
      const res = await axios.get(`/stats/module/${moduleId}`)
      this.stats = res.data
    },
  },
})
