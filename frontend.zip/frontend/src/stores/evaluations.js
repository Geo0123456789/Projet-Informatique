import { defineStore } from 'pinia'
import { getQuestions, submitEvaluation, getEvaluationStats } from '@/api/evaluations.api'

export const useEvaluationStore = defineStore('evaluations', {
  state: () => ({
    questions: [],
    stats: {},
  }),
  actions: {
    async fetchQuestions() {
      const { data } = await getQuestions()
      this.questions = data
      return data
    },
    async submitEvaluation(moduleId, responses) {
      const formatted = Object.entries(responses).map(([question_id, reponse]) => ({
        question_id,
        reponse,
      }))
      await submitEvaluation(moduleId, formatted)
    },
    async fetchStats(moduleId) {
      const { data } = await getEvaluationStats(moduleId)
      this.stats = data
      return data
    },
  },
})