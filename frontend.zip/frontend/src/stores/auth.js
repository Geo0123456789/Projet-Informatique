import { defineStore } from 'pinia'
import { login as apiLogin, getUserProfile } from '@/api/auth.api'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: null,
    token: localStorage.getItem('token') || null,
  }),
  actions: {
    async login(credentials) {
      const { data } = await apiLogin(credentials)
      this.token = data.token
      localStorage.setItem('token', data.token)
      await this.fetchUser()
    },
    async fetchUser() {
      const { data } = await getUserProfile()
      this.user = data
    },
    logout() {
      this.user = null
      this.token = null
      localStorage.removeItem('token')
    },
  },
})
