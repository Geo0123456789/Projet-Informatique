import axios from '@/lib/axios'
import { defineStore } from 'pinia'

export const useEtudiantStore = defineStore('etudiant', {
  state: () => ({
    modules: [],
  }),
  actions: {
    async fetchModules() {
      const res = await axios.get('/modules')
      this.modules = res.data
    },
  },
})