import { defineStore } from 'pinia'
import axios from '@/lib/axios'

export const useModuleStore = defineStore('modules', {
  state: () => ({
    modules: [],
  }),
  actions: {
    async fetchStudentModules() {
      const { data } = await axios.get('/modules')
      this.modules = data
      return data
    },
    async fetchAllModules() {
      const { data } = await axios.get('/modules')
      this.modules = data
      return data
    },
    async fetchModuleById(id) {
      const { data } = await axios.get(`/modules/${id}`)
      return data
    },
  },
})