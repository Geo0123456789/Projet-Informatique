<template>
  <DefaultLayout>
    <h2 class="text-xl font-semibold mb-4">Statistiques</h2>
    <div class="mb-6">
      <p class="font-bold">Moyenne globale : {{ stats.moyenne }}</p>
      <canvas ref="chartEl" class="mt-4 max-w-md"></canvas>
    </div>
  </DefaultLayout>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import { Chart } from 'chart.js/auto'
import DefaultLayout from '@/layouts/DefaultLayout.vue'
import { useEvaluationStore } from '@/stores/evaluations'

const route = useRoute()
const stats = ref({})
const chartEl = ref(null)
const store = useEvaluationStore()

onMounted(async () => {
  stats.value = await store.fetchStats(route.params.id)
  new Chart(chartEl.value, {
    type: 'bar',
    data: {
      labels: stats.value.criteres,
      datasets: [
        {
          label: 'Note moyenne',
          backgroundColor: '#3b82f6',
          data: stats.value.notes,
        },
      ],
    },
  })
})
</script>
