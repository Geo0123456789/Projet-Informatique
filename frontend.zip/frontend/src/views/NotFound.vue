<template>
  <div class="flex flex-col items-center justify-center min-h-screen text-center p-6">
    <h1 class="text-6xl font-bold text-blue-600 mb-4">404</h1>
    <p class="text-lg mb-6">Page non trouvée</p>
    <router-link to="/" class="text-blue-500 underline">Retour à l'accueil</router-link>
  </div>
</template>

<script setup></script>
