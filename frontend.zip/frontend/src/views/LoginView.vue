<template>
  <div class="max-w-md mx-auto mt-20 p-6 border rounded">
    <h2 class="text-xl font-bold mb-4">Connexion</h2>

    <BaseInput v-model="email" label="Email" />
    <BaseInput v-model="password" label="Mot de passe" type="password" />

    <BaseButton @click="handleLogin">Se connecter</BaseButton>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import BaseInput from '@/components/BaseInput.vue'
import BaseButton from '@/components/BaseButton.vue'

const auth = useAuthStore()
const router = useRouter()

const email = ref('')
const password = ref('')

const handleLogin = async () => {
  try {
    await auth.login({ email: email.value, password: password.value })
    if (auth.user?.role === 'etudiant') {
      router.push('/etudiant')
    } else {
      router.push('/responsable')
    }
  } catch (err) {
    alert("Échec de connexion")
  }
}
</script>
