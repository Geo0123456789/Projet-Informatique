<template>
  <div class="p-6">
    <h1 class="text-xl font-semibold mb-4">Modules à évaluer</h1>

    <div v-if="modules.length === 0">Aucun module disponible</div>
    <div class="grid gap-4">
      <div
        v-for="m in modules"
        :key="m.id"
        class="border p-4 rounded flex justify-between items-center"
      >
        <div>
          <h2 class="font-semibold">{{ m.nom }}</h2>
          <p>Enseignant : {{ m.enseignant }}</p>
          <p>Semestre : {{ m.semestre }}</p>
        </div>
        <router-link
          v-if="!m.evalue"
          :to="`/etudiant/module/${m.id}`"
          class="text-blue-600 hover:underline"
        >
          Évaluer
        </router-link>
        <span v-else class="text-green-600">Déjà évalué</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useModuleStore } from '@/stores/modules'

const moduleStore = useModuleStore()
const modules = moduleStore.modules

onMounted(() => {
  moduleStore.fetchStudentModules()
})
</script>
