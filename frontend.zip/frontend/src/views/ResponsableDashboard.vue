<template>
  <div class="p-6">
    <h1 class="text-xl font-semibold mb-4">Synthèse des évaluations</h1>

    <div class="grid gap-4">
      <div
        v-for="m in modules"
        :key="m.id"
        class="border p-4 rounded flex justify-between items-center"
      >
        <div>
          <h2 class="font-semibold">{{ m.nom }}</h2>
          <p>Enseignant : {{ m.enseignant }}</p>
        </div>
        <router-link :to="`/responsable/stats/${m.id}`" class="text-blue-600 hover:underline">
          Voir stats
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useModuleStore } from '@/stores/modules'

const moduleStore = useModuleStore()
const modules = moduleStore.modules

onMounted(() => {
  moduleStore.fetchAllModules()
})
</script>
