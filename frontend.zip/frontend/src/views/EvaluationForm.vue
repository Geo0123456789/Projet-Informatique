<template>
  <div class="p-6 max-w-3xl mx-auto">
    <h2 class="text-xl font-semibold mb-4">Évaluation du module : {{ module?.nom }}</h2>

    <form @submit.prevent="submitEvaluation">
      <div v-for="q in questions" :key="q.id">
        <EvaluationQuestion
          :question="q"
          v-model="responses[q.id]"
        />
      </div>

      <BaseButton type="submit" class="mt-4">Envoyer l'évaluation</BaseButton>
    </form>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useEvaluationStore } from '@/stores/evaluations'
import { useModuleStore } from '@/stores/modules'
import EvaluationQuestion from '@/components/EvaluationQuestion.vue'
import BaseButton from '@/components/BaseButton.vue'

const route = useRoute()
const router = useRouter()
const moduleId = route.params.id

const evaluationStore = useEvaluationStore()
const moduleStore = useModuleStore()

const module = ref(null)
const questions = ref([])
const responses = ref({})

onMounted(async () => {
  module.value = await moduleStore.fetchModuleById(moduleId)
  questions.value = await evaluationStore.fetchQuestions()

  for (const q of questions.value) {
    responses.value[q.id] = ''
  }
})

const submitEvaluation = async () => {
  try {
    await evaluationStore.submitEvaluation(moduleId, responses.value)
    alert('Évaluation soumise avec succès !')
    router.push('/etudiant')
  } catch (err) {
    alert('Erreur lors de la soumission.')
  }
}
</script>
