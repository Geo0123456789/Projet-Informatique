import { createRouter, createWebHistory } from 'vue-router'
import EtudiantModules from '@/pages/etudiant/EtudiantModules.vue'
import EvaluationForm from '@/pages/etudiant/EvaluationForm.vue'
import ResponsableModules from '@/pages/responsable/ResponsableModules.vue'
import ModuleStats from '@/pages/responsable/ModuleStats.vue'
import Login from '@/pages/Login.vue'

const routes = [
  {
    path: '/',
    redirect: '/login',
  },
  {
    path: '/login',
    name: 'Login',
    component: Login,
  },

  // Étudiant
  {
    path: '/etudiant/modules',
    name: 'EtudiantModules',
    component: EtudiantModules,
  },
  {
    path: '/etudiant/evaluer/:moduleId',
    name: 'EvaluationForm',
    component: EvaluationForm,
    props: true,
  },

  // Responsable
  {
    path: '/responsable/modules',
    name: 'ResponsableModules',
    component: ResponsableModules,
  },
  {
    path: '/responsable/modules/:id/stats',
    name: 'ModuleStats',
    component: ModuleStats,
    props: true,
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
