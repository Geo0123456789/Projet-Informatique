
<template>
  <div class="mb-4">
    <label class="block font-medium mb-1">{{ label }}</label>
    <select
      v-model="modelValue"
      class="w-full border rounded px-3 py-2"
      @change="$emit('update:modelValue', $event.target.value)"
    >
      <option value="" disabled>-- Sélectionner --</option>
      <option v-for="opt in options" :key="opt.value" :value="opt.value">
        {{ opt.label }}
      </option>
    </select>
  </div>
</template>

<script setup>
defineProps({
  modelValue: [String, Number],
  label: String,
  options: Array,
})
</script>
