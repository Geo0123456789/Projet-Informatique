
<template>
  <div class="mb-6">
    <p class="mb-2 font-semibold">{{ question.intitule }}</p>

    <div v-if="question.type === 'note'">
      <label
        v-for="n in 5"
        :key="n"
        class="inline-flex items-center mr-3"
      >
        <input
          type="radio"
          :name="'question-' + question.id"
          :value="n"
          v-model="localResponse"
          @change="$emit('update:modelValue', localResponse)"
        />
        <span class="ml-1">{{ n }}</span>
      </label>
    </div>

    <div v-else>
      <textarea
        v-model="localResponse"
        class="w-full border rounded px-3 py-2"
        rows="3"
        @input="$emit('update:modelValue', localResponse)"
      ></textarea>
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  question: Object,
  modelValue: [String, Number],
})

const localResponse = ref(props.modelValue)

watch(() => props.modelValue, (newVal) => {
  localResponse.value = newVal
})
</script>
