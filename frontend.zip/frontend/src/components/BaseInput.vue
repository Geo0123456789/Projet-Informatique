
<template>
  <div class="mb-4">
    <label class="block font-medium mb-1">{{ label }}</label>
    <input
      :type="type"
      v-model="modelValue"
      class="w-full border rounded px-3 py-2"
      :placeholder="placeholder"
      @input="$emit('update:modelValue', $event.target.value)"
    />
  </div>
</template>

<script setup>
defineProps({
  modelValue: String,
  label: String,
  placeholder: String,
  type: {
    type: String,
    default: 'text',
  },
})
</script>
