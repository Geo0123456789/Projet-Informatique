<template>
  <canvas ref="canvas"></canvas>
</template>

<script setup>
import { onMounted, ref, watch } from 'vue'
import Chart from 'chart.js/auto'

const props = defineProps({ data: Object })
const canvas = ref(null)
let chart = null

onMounted(() => {
  createChart()
})

watch(() => props.data, () => {
  if (chart) chart.destroy()
  createChart()
})

const createChart = () => {
  if (!props.data) return

  chart = new Chart(canvas.value, {
    type: 'bar',
    data: {
      labels: props.data.labels,
      datasets: [{
        label: 'Répartition des notes',
        data: props.data.valeurs,
        backgroundColor: '#3b82f6'
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      }
    }
  })
}
</script>
