<template>
  <div class="mb-4">
    <label v-if="label" class="block mb-1 font-medium">{{ label }}</label>
    <textarea
      v-bind="$attrs"
      class="w-full p-2 border rounded focus:outline-none focus:ring focus:border-blue-300"
    />
  </div>
</template>

<script setup>
defineProps({
  label: String,
})
</script>
