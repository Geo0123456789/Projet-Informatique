<template>
  <RouterView />
</template>

<script setup></script>

<style>
body {
  font-family: 'Inter', sans-serif;
}
</style>
