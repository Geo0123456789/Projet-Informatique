import axios from './axios'

export const getQuestions = () => {
  return axios.get('/questions')
}

export const submitEvaluation = (answers, moduleId) => {
  return axios.post('/evaluations', {
    module_id: moduleId,
    reponses: answers,
  })
}

export const getEvaluationStats = (moduleId) => {
  return axios.get(`/stats/module/${moduleId}`)
}
