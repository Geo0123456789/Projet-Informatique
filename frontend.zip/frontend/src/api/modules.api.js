import axios from './axios'

// modules accessible par tous les rôles

export const getAllModules = () => {
  return axios.get('/modules')
}

// un module en particulier

export const getModuleById = (id) => {
  return axios.get(`/modules/${id}`)
}
