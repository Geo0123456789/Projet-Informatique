import axios from './axios'

export const getAllQuestions = () => {
  return axios.get('/questions')
}

export const createQuestion = (question) => {
  return axios.post('/questions', question)
}

export const updateQuestion = (id, question) => {
  return axios.put(`/questions/${id}`, question)
}

export const deleteQuestion = (id) => {
  return axios.delete(`/questions/${id}`)
}
