import axios from './axios'

export const login = (credentials) => {
  return axios.post('/login', credentials)
}

export const register = (data) => {
  return axios.post('/register', data)
}

export const getUserProfile = () => {
  return axios.get('/me')
}
