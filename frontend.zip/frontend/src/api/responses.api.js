import axios from './axios'

export const getResponsesByEvaluation = (evaluationId) => {
  return axios.get(`/responses/evaluation/${evaluationId}`)
}
