<template>
  <div class="min-h-screen bg-gray-50">
    <header class="bg-white shadow p-4 flex justify-between items-center">
      <h1 class="text-xl font-bold">Évaluations des Cours</h1>
      <div v-if="auth.isAuthenticated">
        <router-link
          :to="auth.user?.role === 'etudiant' ? '/etudiant' : '/responsable'"
          class="text-blue-600 hover:underline"
        >
          Tableau de bord
        </router-link>
        <span class="mr-4">{{ auth.user?.nom }}</span>
        <button @click="logout" class="text-red-600 hover:underline">Déconnexion</button>
        <button @click="handleLogout" class="text-red-600 hover:underline">Déconnexion</button>

      </div>
    </header>

    <main class="p-4">
      <slot />
    </main>
  </div>
</template>

<script setup>
import { useAuthStore } from '@/stores/auth'
import { useRouter } from 'vue-router'

const auth = useAuthStore()
const router = useRouter()

const logout = () => {
  auth.logout()
  router.push('/login')
}

const handleLogout = () => {
  if (confirm('Voulez-vous vraiment vous déconnecter ?')) {
    auth.logout()
    router.push('/login')
  }
}

</script>
